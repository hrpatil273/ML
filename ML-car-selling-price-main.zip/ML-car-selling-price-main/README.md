# ML-car-selling-price
Forecasting the Selling Price of Used 2012 Cars: A Machine Learning Approach
